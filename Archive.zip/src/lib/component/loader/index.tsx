import './index.css'

const RadarLoading = () => {
  return (
    <div>
      <div className="loader">
        <span></span>
      </div>
    </div>
  );
}

export default RadarLoading